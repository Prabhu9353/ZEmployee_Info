sap.ui.define(["sap/m/MessageToast"],function(n){"use strict";return{onDownload:function(o){n.show("Custom handler invoked.")}}});
//# sourceMappingURL=CompanyDownload.js.map