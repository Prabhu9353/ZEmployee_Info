sap.ui.define(["sap/m/MessageToast"],function(n){"use strict";return{onUpload:function(s){n.show("Custom handler invoked.")}}});
//# sourceMappingURL=CompanyUpload.js.map